

/************** MAKE CHANGES HERE ********************/
#include "stm32f1xx_hal.h"
#include "main.h"
#include "DHT.h"

/*******************************************     NO CHANGES AFTER THIS LINE      ****************************************************/

uint8_t hum1, hum2, tempC1, tempC2, SUM, CHECK;
uint32_t pMillis, cMillis;

#include "DHT.h"

uint32_t DWT_Delay_Init(void)
{
  /* Disable TRC */
  CoreDebug->DEMCR &= ~CoreDebug_DEMCR_TRCENA_Msk; // ~0x01000000;
  /* Enable TRC */
  CoreDebug->DEMCR |=  CoreDebug_DEMCR_TRCENA_Msk; // 0x01000000;

  /* Disable clock cycle counter */
  DWT->CTRL &= ~DWT_CTRL_CYCCNTENA_Msk; //~0x00000001;
  /* Enable  clock cycle counter */
  DWT->CTRL |=  DWT_CTRL_CYCCNTENA_Msk; //0x00000001;

  /* Reset the clock cycle counter value */
  DWT->CYCCNT = 0;

     /* 3 NO OPERATION instructions */
     __ASM volatile ("NOP");
     __ASM volatile ("NOP");
  __ASM volatile ("NOP");

  /* Check if clock cycle counter has started */
     if(DWT->CYCCNT)
     {
       return 0; /*clock cycle counter started*/
     }
     else
  {
    return 1; /*clock cycle counter not started*/
  }
}

__STATIC_INLINE void delay(volatile uint32_t microseconds)
{
  uint32_t clk_cycle_start = DWT->CYCCNT;

  /* Go to number of cycles for system */
  microseconds *= (HAL_RCC_GetHCLKFreq() / 1000000);

  /* Delay till end */
  while ((DWT->CYCCNT - clk_cycle_start) < microseconds);
}

void DHT_Start (void)
{
	  uint8_t Response = 0;

	  DWT_Delay_Init();

	  GPIO_InitTypeDef GPIO_InitStructPrivate = {0};
	  GPIO_InitStructPrivate.Pin = DHT_Pin;
	  GPIO_InitStructPrivate.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStructPrivate.Speed = GPIO_SPEED_FREQ_LOW;
	  GPIO_InitStructPrivate.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(DHT_GPIO_Port, &GPIO_InitStructPrivate);
	  HAL_GPIO_WritePin (DHT_GPIO_Port, DHT_Pin, 0);
	  delay (1300);
	  HAL_GPIO_WritePin (DHT_GPIO_Port, DHT_Pin, 1);
	  delay (30);
	  GPIO_InitStructPrivate.Mode = GPIO_MODE_INPUT;
	  GPIO_InitStructPrivate.Pull = GPIO_PULLUP;
	  HAL_GPIO_Init(DHT_GPIO_Port, &GPIO_InitStructPrivate);
	  delay (40);
	  if (!(HAL_GPIO_ReadPin (DHT_GPIO_Port, DHT_Pin)))
	  {
	    delay (80);
	    if ((HAL_GPIO_ReadPin (DHT_GPIO_Port, DHT_Pin))) Response = 1;
	  }
	  pMillis = HAL_GetTick();
	  cMillis = HAL_GetTick();
	  while ((HAL_GPIO_ReadPin (DHT_GPIO_Port, DHT_Pin)) && pMillis + 2 > cMillis)
	  {
	    cMillis = HAL_GetTick();
	  }
	  return Response;
}

uint8_t DHT_Read (void)
{
	uint8_t x,y;
	  for (x=0;x<8;x++)
	  {
	    pMillis = HAL_GetTick();
	    cMillis = HAL_GetTick();
	    while (!(HAL_GPIO_ReadPin (DHT_GPIO_Port, DHT_Pin)) && pMillis + 2 > cMillis)
	    {
	      cMillis = HAL_GetTick();
	    }
	    delay (40);
	    if (!(HAL_GPIO_ReadPin (DHT_GPIO_Port, DHT_Pin)))   // if the pin is low
	      y&= ~(1<<(7-x));
	    else
	      y|= (1<<(7-x));
	    pMillis = HAL_GetTick();
	    cMillis = HAL_GetTick();
	    while ((HAL_GPIO_ReadPin (DHT_GPIO_Port, DHT_Pin)) && pMillis + 2 > cMillis)
	    {  // wait for the pin to go low
	      cMillis = HAL_GetTick();
	    }
	  }
	  return y;
}



void DHT_GetData (DHT_DataTypedef *DHT_Data)
{
    DHT_Start ();
    hum1 = DHT_Read ();
	hum2 = DHT_Read ();
	tempC1 = DHT_Read ();
	tempC2 = DHT_Read ();
	SUM = DHT_Read();

	CHECK = hum1 + hum2 + tempC1 + tempC2;

	if (SUM == CHECK)
	{
		if (tempC1>127)
		{
			DHT_Data->Temperature = (float)tempC2/10*(-1);
		}
		else
		{
			DHT_Data->Temperature = (float)((tempC1<<8)|tempC2)/10;
		}

		DHT_Data->Humidity = (float) ((hum1<<8)|hum2)/10;
	}
}


