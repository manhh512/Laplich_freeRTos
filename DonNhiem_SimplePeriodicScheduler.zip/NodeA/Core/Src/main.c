/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "LoRa.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include "i2c-lcd.h"
#include "DHT.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi2;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

typedef struct {
	DHT_DataTypedef dhtData;	//Lưu dữ liệu từ cảm biến nhiệt độ, độ ẩm (DHT22)
	int check_sum;				//Lưu giá trị kiểm tra (checksum) để đảm bảo tính toàn vẹn của dữ liệu khi lưu trữ hoặc truyền đi.
} AllData;						//Cấu trúc dữ liệu chính AllData

AllData Data;					//Tạo ra một biến tên là Data có cấu trúc như AllData đã định nghĩa ở trên.

LoRa LoRa_tx; // Khai báo đối tượng LoRa cho bên gửi

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

int calculate_checksum(AllData *data);       			//Tính toán giá trị kiểm tra (checksum) cho một gói dữ liệu. Nó nhận vào một con trỏ tới cấu trúc AllData, tính toán checksum dựa trên các trường dữ liệu bên trong (nhiệt độ, độ ẩm) và trả về kết quả là một số nguyên (int).
static void send_uart_sensor_data(AllData *data);		//Gửi toàn bộ dữ liệu cảm biến (được đóng gói trong cấu trúc AllData) qua giao tiếp UART
static void send_uart_text (char *string);				//Gửi một chuỗi văn bản (text string) bất kỳ qua giao tiếp UART
uint8_t receive[10];  // mang nay cho ngat receive
uint8_t BUFF_IT[] = "\n[ngat batdau]\n";
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == huart1.Instance)
	{
		HAL_UART_Receive_IT(&huart1, receive, 1);
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		HAL_UART_Transmit(&huart1, BUFF_IT, 16, 300);
		send_uart_sensor_data(&Data);

	}
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  HAL_UART_Receive_IT(&huart1, receive, 1);  // <-- DÒNG NÀY BỊ THIẾU

  /* USER CODE BEGIN 2 */



  printf("[Task khoi tao][%lu ms] taskkhoitao batdau!\n", HAL_GetTick());
    lcd_init ();												//Khởi tạo màn hình LCD.
    printf("Khoi tao LCD THANH CONG!\n");
     // Cấu hình các chân phần cứng cho đối tượng LoRa
    LoRa_tx = newLoRa();
    LoRa_tx.CS_port        = GPIOA;
    LoRa_tx.CS_pin         = GPIO_PIN_4;
    LoRa_tx.reset_port     = GPIOC;
    LoRa_tx.reset_pin      = GPIO_PIN_14;
    LoRa_tx.DIO0_port      = GPIOB;
    LoRa_tx.DIO0_pin       = GPIO_PIN_0;
    LoRa_tx.hSPIx          = &hspi2;

    // ================================================================
    // BƯỚC KIỂM TRA QUAN TRỌNG NHẤT
    // ================================================================
    LoRa_reset(&LoRa_tx);

    // BƯỚC 3: Gọi LoRa_init() để kiểm tra
    uint16_t lora_status = LoRa_init(&LoRa_tx);

    if (lora_status == LORA_OK) {
        printf("Khoi tao LoRa THANH CONG!\n");
    } else {
        // Đọc lại thanh ghi version một lần nữa để xem giá trị của nó là gì
        uint8_t version = LoRa_read(&LoRa_tx, 0x42); // 0x42 là địa chỉ RegVersion
        printf("Khoi tao LoRa THAT BAI! Ma loi: %d\n", lora_status);
        printf("Gia tri doc duoc tu Version Register (0x42) la: 0x%X\n", version);
        printf("Gia tri dung phai la: 0x12\n");
    }
    HAL_Delay(20000);
  /* USER CODE END 2 */
    printf("[Task khoi tao][%lu ms] taskkhoitao ketthuc!\n", HAL_GetTick());
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  /*Khai báo biến cục bộ*/
	  char LCD_data[16];									//Là các mảng ký tự (chuỗi) để định dạng dữ liệu trước khi hiển thị lên LCD
	  printf("[Task DHT ][%lu ms] taskDHT batdau!\n", HAL_GetTick());
	  /*Đọc Cảm biến DHT*/
	  DHT_GetData(&Data.dhtData);

	  Data.check_sum = (int)(Data.dhtData.Humidity + Data.dhtData.Temperature); //Giá trị checksum bằng tổng tất cả các giá trị cảm biến chính
	  printf("[Task DHT ][%lu ms] taskDHT keththuc!\n", HAL_GetTick());
	  HAL_Delay(10000);

	  printf("[Task gui uart  ][%lu ms] taskuart batdau!\n", HAL_GetTick());
	  /*Gửi UART*/
	  send_uart_sensor_data(&Data);
	  printf("[Task gui uart  ][%lu ms] taskuart ketthuc!\n", HAL_GetTick());
	  HAL_Delay(1000);
	  // Tạo một biến đếm tĩnh để dữ liệu gửi đi thay đổi mỗi lần
	  printf("[Task gui lora  ][%lu ms] tasklora!\n", HAL_GetTick());
	  static uint32_t counter = 0; // Biến đếm để kiểm tra gói tin
	  char payload_buffer[50]; // Buffer để chứa chuỗi tin nhắn

	  // Tạo chuỗi tin nhắn cần gửi, có kèm theo số đếm

	  sprintf(payload_buffer, "T:%.1f,H:%.1f,C:%lu", Data.dhtData.Temperature, Data.dhtData.Humidity, counter++);

	  // Gọi hàm gửi gói tin đi

	  LoRa_transmit(&LoRa_tx, (uint8_t*)payload_buffer, strlen(payload_buffer), 1000);

	  // Nháy led mỗi lần gửi
	  HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);

	  // In ra Hercules của chính Node A để chúng ta biết nó đã gửi
	  printf("Da gui: %s\n", payload_buffer);

	  printf("[Task gui lora  ][%lu ms] taskuart lora!\n", HAL_GetTick());
	  HAL_Delay(5000);

	  printf("[Task LCD ][%lu ms] taskLCD batdau!\n", HAL_GetTick());
	  /*Hiển thị LCD*/
	  sprintf (LCD_data,"T:%.1fC",Data.dhtData.Temperature);//Chuyển đổi giá trị số thành một chuỗi ký tự có định dạng dễ đọc
	  lcd_put_cur (0,0);									//Đặt vị trí con trỏ tới đúng vị trí trên màn hình LCD nơi dữ liệu sẽ được hiển thị
	  lcd_send_string(LCD_data);							//Gửi chuỗi đã định dạng ra màn hình tại vị trí con trỏ

	  sprintf (LCD_data,"H:%.1fRH",Data.dhtData.Humidity);
	  lcd_put_cur (0,8);
	  lcd_send_string(LCD_data);
	  printf("[Task LCD ][%lu ms] taskLCD ketthuc!\n", HAL_GetTick());
	  HAL_Delay(5000);
	  // Chờ 10 giây cho lần gửi tiếp theo
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LED_Pin|Reset_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DHT_GPIO_Port, DHT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_Pin Reset_Pin */
  GPIO_InitStruct.Pin = LED_Pin|Reset_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : NSS_Pin */
  GPIO_InitStruct.Pin = NSS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(NSS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DI0_Pin */
  GPIO_InitStruct.Pin = DI0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DI0_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DHT_Pin */
  GPIO_InitStruct.Pin = DHT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DHT_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
PUTCHAR_PROTOTYPE
{
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}

int calculate_checksum(AllData *data) {
    int temp_int = (int)(data->dhtData.Temperature * 100); // Nhân 100 để giữ giá trị thập phân
    int hum_int = (int)(data->dhtData.Humidity * 100);

    int sum = temp_int + hum_int;
    return sum % 100000; // Giới hạn giá trị checksum
}

/*Gửi một chuỗi văn bản (text string) bất kỳ qua UART*/
void send_uart_text (char *string)
{
	uint8_t len = strlen (string);										//Tính độ dài của chuỗi
	HAL_UART_Transmit(&huart1, (uint8_t *) string, len, HAL_MAX_DELAY); //Gửi chuỗi đó đi ở chế độ blocking (chờ đến khi gửi xong)
}

void send_uart_sensor_data(AllData *data) {
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "Temp: %.1fC \nHumid: %.1fRh\r\n", Data.dhtData.Temperature, Data.dhtData.Humidity);
    send_uart_text(buffer);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
