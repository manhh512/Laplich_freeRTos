/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LoRa.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include "i2c-lcd.h"
#include "DHT.h"
#include "queue.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi2;

UART_HandleTypeDef huart1;

/* Definitions for TaskTEM */
osThreadId_t TaskTEMHandle;
const osThreadAttr_t TaskTEM_attributes = {
  .name = "TaskTEM",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for myTaskHUMI */
osThreadId_t myTaskHUMIHandle;
const osThreadAttr_t myTaskHUMI_attributes = {
  .name = "myTaskHUMI",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for myTaskLORA */
osThreadId_t myTaskLORAHandle;
const osThreadAttr_t myTaskLORA_attributes = {
  .name = "myTaskLORA",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for myTaskLCD */
osThreadId_t myTaskLCDHandle;
const osThreadAttr_t myTaskLCD_attributes = {
  .name = "myTaskLCD",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for myTasktest */
osThreadId_t myTasktestHandle;
const osThreadAttr_t myTasktest_attributes = {
  .name = "myTasktest",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for myBinarySem01 */
osSemaphoreId_t myBinarySem01Handle;
const osSemaphoreAttr_t myBinarySem01_attributes = {
  .name = "myBinarySem01"
};
/* USER CODE BEGIN PV */

typedef struct {
	DHT_DataTypedef dhtData;	//Lưu dữ liệu từ cảm biến nhiệt độ, độ ẩm (DHT22)
	int check_sum;				//Lưu giá trị kiểm tra (checksum) để đảm bảo tính toàn vẹn của dữ liệu khi lưu trữ hoặc truyền đi.
} AllData;						//Cấu trúc dữ liệu chính AllData

AllData Data;					//Tạo ra một biến tên là Data có cấu trúc như AllData đã định nghĩa ở trên.

LoRa LoRa_tx; // Khai báo đối tượng LoRa cho bên gửi
xQueueHandle HumiQueue;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C1_Init(void);
void StartDefaultTEM(void *argument);
void StartTaskHUMI(void *argument);
void StartTaskLORA(void *argument);
void StartTaskLCD(void *argument);
void StartTasktest(void *argument);

/* USER CODE BEGIN PFP */
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

int calculate_checksum(AllData *data);       			//Tính toán giá trị kiểm tra (checksum) cho một gói dữ liệu. Nó nhận vào một con trỏ tới cấu trúc AllData, tính toán checksum dựa trên các trường dữ liệu bên trong (nhiệt độ, độ ẩm) và trả về kết quả là một số nguyên (int).
static void send_uart_sensor_data(AllData *data);		//Gửi toàn bộ dữ liệu cảm biến (được đóng gói trong cấu trúc AllData) qua giao tiếp UART
static void send_uart_text (char *string);				//Gửi một chuỗi văn bản (text string) bất kỳ qua giao tiếp UART
uint8_t receive[10];  // mang nay cho ngat receive

uint8_t BUFF_IT[] = "\n[ngat batdau]\n";
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == huart1.Instance)
	{
		HAL_UART_Receive_IT(&huart1, receive, 1);
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		HAL_UART_Transmit(&huart1, BUFF_IT, 16, 300);
		send_uart_sensor_data(&Data);

	}
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart1, receive, 1);
  System_Init();
  //tạo queue
  /* USER CODE BEGIN RTOS_QUEUES */
	HumiQueue = xQueueCreate(5, sizeof (float));
	if(HumiQueue == 0)
	{
		char str[] = "loi khi tao queue humi \n";
		HAL_UART_Transmit(&huart1, (uint8_t *) str, strlen(str), 1000);
	}
	else
	{
		char str[] = "Queue humi is OK\n";
		HAL_UART_Transmit(&huart1, (uint8_t *) str, strlen(str), 1000);
	}

  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of myBinarySem01 */
  myBinarySem01Handle = osSemaphoreNew(1, 1, &myBinarySem01_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */



  /* Create the thread(s) */
  /* creation of TaskTEM */
  TaskTEMHandle = osThreadNew(StartDefaultTEM, NULL, &TaskTEM_attributes);

  /* creation of myTaskHUMI */
  myTaskHUMIHandle = osThreadNew(StartTaskHUMI, NULL, &myTaskHUMI_attributes);

  /* creation of myTaskLORA */
  myTaskLORAHandle = osThreadNew(StartTaskLORA, NULL, &myTaskLORA_attributes);

  /* creation of myTaskLCD */
  myTaskLCDHandle = osThreadNew(StartTaskLCD, NULL, &myTaskLCD_attributes);

  /* creation of myTasktest */
  myTasktestHandle = osThreadNew(StartTasktest, NULL, &myTasktest_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LED_Pin|Reset_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DHT_GPIO_Port, DHT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_Pin Reset_Pin */
  GPIO_InitStruct.Pin = LED_Pin|Reset_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : NSS_Pin */
  GPIO_InitStruct.Pin = NSS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(NSS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DI0_Pin */
  GPIO_InitStruct.Pin = DI0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DI0_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DHT_Pin */
  GPIO_InitStruct.Pin = DHT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DHT_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
PUTCHAR_PROTOTYPE
{
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}

int calculate_checksum(AllData *data) {
    int temp_int = (int)(data->dhtData.Temperature * 100); // Nhân 100 để giữ giá trị thập phân
    int hum_int = (int)(data->dhtData.Humidity * 100);

    int sum = temp_int + hum_int;
    return sum % 100000; // Giới hạn giá trị checksum
}

/*Gửi một chuỗi văn bản (text string) bất kỳ qua UART*/
void send_uart_text (char *string)
{
	uint8_t len = strlen (string);										//Tính độ dài của chuỗi
	HAL_UART_Transmit(&huart1, (uint8_t *) string, len, HAL_MAX_DELAY); //Gửi chuỗi đó đi ở chế độ blocking (chờ đến khi gửi xong)
}

void send_uart_sensor_data(AllData *data) {
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "Temp: %.1fC \nHumid: %.1fRh\r\n", Data.dhtData.Temperature, Data.dhtData.Humidity);
    send_uart_text(buffer);
}
void System_Init(void)
{
    // Khởi tạo LCD
    lcd_init();
    printf("Khoi tao LCD THANH CONG!\n");

    // Khởi tạo LoRa
    LoRa_tx = newLoRa();
    LoRa_tx.CS_port    = GPIOA;
    LoRa_tx.CS_pin     = GPIO_PIN_4;
    LoRa_tx.reset_port = GPIOC;
    LoRa_tx.reset_pin  = GPIO_PIN_14;
    LoRa_tx.DIO0_port  = GPIOB;
    LoRa_tx.DIO0_pin   = GPIO_PIN_0;
    LoRa_tx.hSPIx      = &hspi2;
    LoRa_reset(&LoRa_tx);
    if (LoRa_init(&LoRa_tx) == LORA_OK) {
        printf("Khoi tao LoRa THANH CONG!\n");
    } else {
        uint8_t version = LoRa_read(&LoRa_tx, 0x42);
        printf("Khoi tao LoRa THAT BAI! Ma loi: %d, Version=0x%X\n", LoRa_init(&LoRa_tx), version);
    }

    // Cấu hình chân DHT
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    GPIO_InitStruct.Pin   = DHT_Pin;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT_GPIO_Port, &GPIO_InitStruct);
    HAL_GPIO_WritePin(DHT_GPIO_Port, DHT_Pin, GPIO_PIN_SET);
    HAL_Delay(6000); // chờ DHT ổn định
    printf("Khoi tao ket thuc! ");

}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTEM */
/**
  * @brief  Function implementing the TaskTEM thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTEM */
void StartDefaultTEM(void *argument)
{
  /* USER CODE BEGIN 5 */
	        char tempBuffer[30];
		    __IO uint32_t time1 = osKernelGetTickCount();
		    printf("[Task 01 ][%lu ms] task01 batdau!\n", HAL_GetTick());
		    for (;;)
		    {
		        time1 = time1 + 10000;
		        DHT_GetData(&Data.dhtData);

//		        sprintf(tempBuffer, "[Task01] Temperature: %.1f°C\n", Data.dhtData.Temperature);
//		        HAL_UART_Transmit(&huart1, (uint8_t *)tempBuffer, strlen(tempBuffer), 300);
		        float Temperature = Data.dhtData.Temperature;
		        printf("[Task01] Temperature: %.1f°C\n", Temperature);
		        // Đẩy độ ẩm vào queue
		        float humidity = Data.dhtData.Humidity;
//		        if(xQueueSend(HumiQueue,&humidity, portMAX_DELAY) == pdPASS)
//		        		{
//		        			char str2[] = "1- Gui Humidity vao Queue thanh cong\n";
//		        			HAL_UART_Transmit(&huart1, (uint8_t *) str2, strlen(str2), 300);
//		        		}
		        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		    	printf("[Task 01 ][%lu ms] task01 keththuc!\n", HAL_GetTick());

//		        osDelayUntil(time1);
		    	osDelay(10000);

		    }


  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartTaskHUMI */
/**
* @brief Function implementing the myTaskHUMI thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTaskHUMI */
void StartTaskHUMI(void *argument)
{
  /* USER CODE BEGIN StartTaskHUMI */
	float received = 0;
	 char Hum[30];
	    __IO uint32_t time2 = osKernelGetTickCount();
	    for (;;)
	    {
		    printf("[Task 02 ][%lu ms] task02 batdau!\n", HAL_GetTick());
	        time2 += 10000;
	        // Đọc độ ẩm trực tiếp từ queue
	        float humi  = Data.dhtData.Humidity;
	        printf("[Task02] Humidity: %.1f°C\n", humi);

	        printf("[Task 02 ][%lu ms] task02 keththuc!\n", HAL_GetTick());


//	        osDelayUntil(time2);
	        osDelay(10000);
	    }
  /* USER CODE END StartTaskHUMI */
}

/* USER CODE BEGIN Header_StartTaskLORA */
/**
* @brief Function implementing the myTaskLORA thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTaskLORA */
void StartTaskLORA(void *argument)
{
  /* USER CODE BEGIN StartTaskLORA */
	__IO uint32_t time3 = osKernelGetTickCount();
		    const uint32_t t3 = 10000;
		    static uint32_t counter = 0;
		    char payload_buffer[50];

		    for (;;)
		    {
		        // Gửi LoRa với semaphore bảo vệ UART

		        printf("[Task 03 ][%lu ms] batdau!\n", HAL_GetTick());
//		        sprintf(payload_buffer, "T:%.1f,H:%.1f,C:%lu", Data.dhtData.Temperature, Data.dhtData.Humidity, counter++);
//		        LoRa_transmit(&LoRa_tx, (uint8_t*)payload_buffer, strlen(payload_buffer), 1000);
//		        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
//		        printf("Da gui: %s\n", payload_buffer);
//
		        time3 += t3;
		    	printf("[Task 03 ][%lu ms] task03 keththuc!\n", HAL_GetTick());
//		        osDelayUntil(time3);
		    	osDelay(10000);
		    }
  /* USER CODE END StartTaskLORA */
}

/* USER CODE BEGIN Header_StartTaskLCD */
/**
* @brief Function implementing the myTaskLCD thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTaskLCD */
void StartTaskLCD(void *argument)
{
  /* USER CODE BEGIN StartTaskLCD */
  /* Infinite loop */
	__IO uint32_t time4 = osKernelGetTickCount();
		    const uint32_t t4 = 5000;
		    char LCD_data[16];
		    for (;;)
		    {
		        // Hiển thị LCD với semaphore
		        printf("[Task 04 ][%lu ms] task04 batdau!\n", HAL_GetTick());
//		        DHT_GetData(&Data.dhtData);
		        float Temperature1 = Data.dhtData.Temperature;
		        float Humidity1    = Data.dhtData.Humidity;

		        // Hiển thị lên LCD

		        // Dòng 1: nhiệt độ
		        sprintf(LCD_data, "Temperature:%d.%dC", (int)Temperature1, (int)(Temperature1 * 10) % 10);
		        lcd_put_cur(0, 0);
		        lcd_send_string(LCD_data);
		        // Dòng 2: độ ẩm
		        sprintf(LCD_data, "Humidity:%d.%dRH", (int)Humidity1, (int)(Humidity1 * 10) % 10);
		        lcd_put_cur(1, 0);
		        lcd_send_string(LCD_data);


		        time4 = time4 + 10000;
		    	printf("[Task 04 ][%lu ms] task04 keththuc!\n", HAL_GetTick());
//		        osDelayUntil(time4);
		    	osDelay(5000);
		    }

  /* USER CODE END StartTaskLCD */
}

/* USER CODE BEGIN Header_StartTasktest */
/**
* @brief Function implementing the myTasktest thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTasktest */
void StartTasktest(void *argument)
{
  /* USER CODE BEGIN StartTasktest */
  /* Infinite loop */
  for(;;)
  {
	  printf("[Task 05 ][%lu ms] task05 batdau!\n", HAL_GetTick());
//	  for(int i =0;i<10;i++){
//		  HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
//		  printf("[Task 05 ][%lu ms] task05 dang chay!\n", HAL_GetTick());
//		  HAL_Delay(10);
//	  }
	  printf("[Task 05 ][%lu ms] task05 keththuc!\n", HAL_GetTick());
	  osDelay(5000);
  }
  /* USER CODE END StartTasktest */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM3 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM3)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
